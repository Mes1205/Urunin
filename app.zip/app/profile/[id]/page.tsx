//app/profile/[id]/page.tsx

"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, User, Calendar, Receipt } from 'lucide-react';

export default function ProfilePage() {
  const { id } = useParams();
  const router = useRouter();
  const [profile, setProfile] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      // 1. Ambil Data Profile User
      const { data: userData } = await supabase
        .from('profiles')
        .select('id, name, email, image_url')
        .eq('id', id)
        .single();
      
      setProfile(userData);

      // 2. Ambil History Struk (Dimana dia jadi pembuat struk)
      // Kalau mau lebih canggih, bisa join sama tabel debts buat liat dia ikutan makan dimana aja
      const { data: historyData } = await supabase
        .from('receipts')
        .select('id, store_name, total_amount, created_at, items_raw')
        .eq('user_id', id)
        .order('created_at', { ascending: false });

      if (historyData) setHistory(historyData);
      setLoading(false);
    };

    fetchData();
  }, [id]);

  if (loading) return <div className="p-10 text-center">Loading Profile...</div>;
  if (!profile) return <div className="p-10 text-center">User tidak ditemukan.</div>;

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-6 px-6 pb-20">
      <div className="max-w-2xl mx-auto">
        
        {/* Navigasi */}
        <button onClick={() => router.back()} className="mb-6 flex items-center gap-2 text-gray-500 hover:text-[#2D2924]">
          <ArrowLeft size={18}/> Kembali
        </button>

        {/* Header Profile */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-amber-100 text-center mb-8 animate-in slide-in-from-bottom-4">
           <div className="w-24 h-24 mx-auto bg-amber-100 rounded-full flex items-center justify-center mb-4 overflow-hidden border-4 border-white shadow-lg">
             {profile.image_url ? (
               <img src={profile.image_url} alt={profile.name} className="w-full h-full object-cover"/>
             ) : (
               <User size={40} className="text-amber-700"/>
             )}
           </div>
           <h1 className="text-2xl font-black text-[#2D2924]">{profile.name || 'Tanpa Nama'}</h1>
           <p className="text-gray-400 text-sm">{profile.email}</p>
        </div>

        {/* History Section */}
        <h2 className="font-bold text-[#2D2924] mb-4 flex items-center gap-2">
          <Receipt size={20} className="text-amber-600"/> Riwayat Split Bill
        </h2>

        {history.length === 0 ? (
          <div className="text-center py-10 text-gray-400 bg-white rounded-2xl border border-dashed border-gray-200">
            Belum ada riwayat transaksi.
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item) => {
              // Parse items buat preview dikit (ambil 2 menu pertama aja)
              const itemsList = JSON.parse(item.items_raw || '[]');
              const previewItems = itemsList.slice(0, 2).map((i: any) => i.name).join(', ');
              const moreCount = itemsList.length - 2;

              return (
                <div 
                  key={item.id} 
                  onClick={() => router.push(`/receipt/${item.id}`)}
                  className="bg-white p-5 rounded-2xl border border-amber-50 shadow-sm hover:shadow-md transition-all cursor-pointer flex justify-between items-center group"
                >
                  <div>
                    <h3 className="font-bold text-[#2D2924] group-hover:text-amber-600 transition-colors">{item.store_name || 'Struk Tanpa Nama'}</h3>
                    <p className="text-xs text-gray-400 mb-2 flex items-center gap-1">
                      <Calendar size={10}/> {new Date(item.created_at).toLocaleDateString('id-ID')}
                    </p>
                    <p className="text-xs text-gray-500 max-w-[200px] truncate">
                      {previewItems} {moreCount > 0 && `+${moreCount} lainnya`}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">Total</p>
                    <p className="font-black text-[#2D2924]">Rp {item.total_amount.toLocaleString()}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
}