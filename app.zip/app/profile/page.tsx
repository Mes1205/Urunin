"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { 
  User, Shield, LogOut, Users, ChevronRight, 
  Settings, X, Check, CreditCard, Bell 
} from 'lucide-react';

export default function ProfilePage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState<any>(null);
  const [stats, setStats] = useState({ friends: 0, transactions: 0 });
  
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchProfileData = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    router.push('/login');
    return;
  }
  setUserData(user);
  setNewName(user.user_metadata?.full_name || '');

  // 1. Ambil jumlah teman REAL dari tabel 'friends'
  const { count: friendsCount } = await supabase
    .from('friends')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', user.id);

  // 2. Ambil jumlah transaksi unik dari tabel 'debts'
  const { count: debtsCount } = await supabase
    .from('debts')
    .select('*', { count: 'exact', head: true })
    .or(`lender_id.eq.${user.id},debtor_id.eq.${user.id}`);

  setStats({
    friends: friendsCount || 0,
    transactions: debtsCount || 0
  });
  setLoading(false);
};

  useEffect(() => {
    fetchProfileData();
  }, [router]);

  const handleUpdateName = async () => {
    setIsUpdating(true);
    const { error } = await supabase.auth.updateUser({
      data: { full_name: newName }
    });

    if (error) {
      alert("Gagal update nama: " + error.message);
    } else {
      setIsEditModalOpen(false);
      fetchProfileData();
    }
    setIsUpdating(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
  };

  if (loading) return (
    <div className="min-h-screen bg-[#FDFCF0] flex items-center justify-center">
      <div className="animate-bounce font-black text-amber-600">URUNIN...</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#FDFCF0] pb-24">
      {/* Top Decor */}
      <div className="h-32 bg-gradient-to-r from-amber-400 to-orange-500 w-full" />

      <div className="max-w-md mx-auto px-6 -mt-16">
        {/* Profile Card */}
        <div className="bg-white rounded-[2.5rem] p-8 shadow-xl shadow-amber-900/5 text-center relative border border-white">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2">
            <div className="w-24 h-24 bg-white p-1.5 rounded-[2rem] shadow-lg">
              <div className="w-full h-full bg-amber-500 rounded-[1.8rem] flex items-center justify-center text-white">
                <User size={40} strokeWidth={2.5} />
              </div>
            </div>
          </div>

          <div className="mt-12">
            <h1 className="text-2xl font-black text-[#2D2924] leading-tight">
              {userData?.user_metadata?.full_name || 'User Urunin'}
            </h1>
            <p className="text-gray-400 font-medium text-sm mt-1">{userData?.email}</p>
          </div>

          {/* Stats Bar - Mirip Layout Instagram tapi lebih playful */}
          <div className="flex items-center justify-around mt-8 pt-6 border-t border-gray-50">
            <button onClick={() => router.push('/friends')} className="flex flex-col items-center group">
              <span className="text-xl font-black text-[#2D2924] group-active:scale-90 transition-transform">{stats.friends}</span>
              <span className="text-[10px] uppercase font-black text-gray-400 tracking-tighter">Teman</span>
            </button>
            <div className="h-8 w-[1px] bg-gray-100" />
            <div className="flex flex-col items-center">
              <span className="text-xl font-black text-[#2D2924]">{stats.transactions}</span>
              <span className="text-[10px] uppercase font-black text-gray-400 tracking-tighter">Transaksi</span>
            </div>
            <div className="h-8 w-[1px] bg-gray-100" />
            <div className="flex flex-col items-center">
              <span className="text-xl font-black text-green-600">Active</span>
              <span className="text-[10px] uppercase font-black text-gray-400 tracking-tighter">Status</span>
            </div>
          </div>
        </div>

        {/* Action Menu Group */}
        <div className="mt-8 space-y-4">
          <h3 className="text-[10px] font-black uppercase text-gray-400 tracking-[0.2em] ml-4">Pengaturan Akun</h3>
          
          <div className="bg-white rounded-[2rem] border border-amber-100/50 shadow-sm overflow-hidden">
            <MenuButton 
              icon={<Settings size={20} className="text-amber-500" />} 
              label="Edit Nama Profil" 
              onClick={() => setIsEditModalOpen(true)} 
            />
            <MenuButton 
              icon={<Bell size={20} className="text-blue-500" />} 
              label="Notifikasi" 
              onClick={() => alert('Segera hadir!')} 
            />
             <MenuButton 
              icon={<CreditCard size={20} className="text-emerald-500" />} 
              label="Metode Pembayaran" 
              onClick={() => alert('Segera hadir!')} 
            />
            <MenuButton 
              icon={<Shield size={20} className="text-purple-500" />} 
              label="Ubah Password" 
              onClick={() => alert('Instruksi dikirim ke email!')} 
            />
          </div>

          <button 
            onClick={handleLogout}
            className="w-full bg-red-50 text-red-500 p-5 rounded-[2rem] font-black flex items-center justify-center gap-3 hover:bg-red-500 hover:text-white transition-all active:scale-95 border border-red-100"
          >
            <LogOut size={20} />
            Keluar dari Urunin
          </button>
        </div>
      </div>

      {/* --- MODAL EDIT NAMA --- */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-end md:items-center justify-center p-4 bg-[#2D2924]/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl animate-in fade-in slide-in-from-bottom-10 duration-300">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-[#2D2924]">Ubah Nama</h2>
              <button onClick={() => setIsEditModalOpen(false)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors">
                <X size={20}/>
              </button>
            </div>
            
            <div className="space-y-2 mb-8">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Nama Lengkap</label>
                <input 
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full bg-[#F9F8F3] border-2 border-amber-100 rounded-2xl p-5 font-bold text-[#2D2924] outline-none focus:border-amber-400 focus:bg-white transition-all"
                placeholder="Masukkan nama baru..."
                />
            </div>

            <button 
              onClick={handleUpdateName}
              disabled={isUpdating}
              className="w-full bg-amber-500 text-white p-5 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-amber-600 disabled:opacity-50 shadow-lg shadow-amber-200 active:scale-95 transition-all"
            >
              {isUpdating ? 'MENYIMPAN...' : <><Check size={20}/> Simpan Perubahan</>}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Sub-komponen untuk tombol menu agar kode lebih bersih
function MenuButton({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center justify-between p-5 hover:bg-amber-50/50 transition-colors group border-b border-gray-50 last:border-0"
    >
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <span className="font-bold text-sm text-[#2D2924]">{label}</span>
      </div>
      <ChevronRight size={18} className="text-gray-300 group-hover:text-amber-500 group-hover:translate-x-1 transition-all" />
    </button>
  );
}