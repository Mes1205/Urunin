"use client";

import React, { useState, useRef, useEffect } from 'react';
import { processReceipt } from './ocr/action';
import { User as SupabaseUser } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { 
  Trash2, User, Receipt, History, 
  ArrowUpRight, ArrowDownLeft, Plus,
  Image as ImageIcon, Camera, ChevronRight,
  Info, Percent, BadgePercent, RefreshCw, Sparkles, Clock
} from 'lucide-react';
import { useRouter } from 'next/navigation';

// --- Interfaces ---
interface ReceiptItem { name: string; price: number; qty: number; }
interface ReceiptData { 
  id: string; 
  store_name?: string; 
  items: ReceiptItem[]; 
  subtotal: number; 
  tax: number; 
  serviceCharge: number; 
  discount: number; 
  totalAmount: number; 
}
interface Participant { id: string; name: string; type: 'friend' | 'dummy'; items: number[]; }
interface OffsetOption { friendId: string; friendName: string; amountYouOwe: number; amountTheyOwe: number; }

export default function OcrPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [step, setStep] = useState<'dashboard' | 'edit' | 'assign'>('dashboard');

  // Dashboard & History Data
  const [history, setHistory] = useState<any[]>([]);
  const [stats, setStats] = useState({ piutang: 0, hutang: 0 });
  const [offsetSuggestions, setOffsetSuggestions] = useState<OffsetOption[]>([]);

  // OCR & Split Logic
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [selectedLenderId, setSelectedLenderId] = useState<string>(''); // Fitur #2
  const [dummyName, setDummyName] = useState('');
  const [friendsSearch, setFriendsSearch] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    init();
  }, []);

  const init = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser();
    setUser(authUser);
    if (authUser) {
      setSelectedLenderId(authUser.id);
      await fetchDashboardData(authUser.id);
      setParticipants([{ id: authUser.id, name: authUser.user_metadata?.full_name || 'Saya', type: 'friend', items: [] }]);
    }
    setLoading(false);
  };

  const fetchDashboardData = async (userId: string) => {
    setLoading(true);
    try {
      // 1. Ambil Utang & Piutang untuk Stats & Offset Logic
      const { data: allDebts } = await supabase
        .from('debts')
        .select(`*, debtor:profiles!debtor_id(name), lender:profiles!lender_id(name)`)
        .or(`lender_id.eq.${userId},debtor_id.eq.${userId}`)
        .eq('is_paid', false);

      if (allDebts) {
        let piutangTotal = 0;
        let hutangTotal = 0;
        const balanceMap: Record<string, { name: string, credit: number, debt: number }> = {};

        allDebts.forEach(d => {
          if (d.lender_id === userId) {
            piutangTotal += d.amount;
            if (d.debtor_id) {
              balanceMap[d.debtor_id] = { ...balanceMap[d.debtor_id], name: d.debtor?.name || 'Teman', credit: (balanceMap[d.debtor_id]?.credit || 0) + d.amount };
            }
          } else {
            hutangTotal += d.amount;
            if (d.lender_id) {
              balanceMap[d.lender_id] = { ...balanceMap[d.lender_id], name: d.lender?.name || 'Teman', debt: (balanceMap[d.lender_id]?.debt || 0) + d.amount };
            }
          }
        });

        setStats({ piutang: piutangTotal, hutang: hutangTotal });

        // Fitur #1: Deteksi Potong Utang
        const suggestions: OffsetOption[] = Object.entries(balanceMap)
          .filter(([_, val]) => val.credit > 0 && val.debt > 0)
          .map(([id, val]) => ({
            friendId: id, friendName: val.name, amountTheyOwe: val.credit, amountYouOwe: val.debt
          }));
        setOffsetSuggestions(suggestions);
      }

      // 2. Ambil History Transaksi
      const { data: receipts } = await supabase
        .from('receipts')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      setHistory(receipts || []);

    } finally {
      setLoading(false);
    }
  };

  // --- Logic Helpers ---
  const calculateExtraCosts = () => {
    if (!receipt) return 0;
    return (receipt.tax || 0) + (receipt.serviceCharge || 0) - (receipt.discount || 0);
  };

  const getFinalTotal = () => {
    if (!receipt) return 0;
    const subtotal = receipt.items.reduce((acc, item) => acc + (item.price * (item.qty || 1)), 0);
    return subtotal + calculateExtraCosts();
  };

  const handleOffset = async (opt: OffsetOption) => {
    const confirm = window.confirm(`Potong utang dengan ${opt.friendName}? Martha bayar ke Ucup Rp ${Math.abs(opt.amountTheyOwe - opt.amountYouOwe).toLocaleString()} saja.`);
    if (!confirm) return;

    setLoading(true);
    try {
      // Tandai semua utang lama sebagai 'offset'
      await supabase.from('debts').update({ is_paid: true, status: 'offset' })
        .or(`and(lender_id.eq.${user?.id},debtor_id.eq.${opt.friendId}),and(lender_id.eq.${opt.friendId},debtor_id.eq.${user?.id})`)
        .eq('is_paid', false);

      // Buat record selisih baru
      const diff = opt.amountTheyOwe - opt.amountYouOwe;
      if (diff !== 0) {
        await supabase.from('debts').insert({
          lender_id: diff > 0 ? user?.id : opt.friendId,
          debtor_id: diff > 0 ? opt.friendId : user?.id,
          amount: Math.abs(diff),
          note: 'Sisa hasil potong utang (Settlement)',
          status: 'pending'
        });
      }
      alert('Berhasil diselesaikan! 🤝');
      fetchDashboardData(user!.id);
    } catch (err) { alert('Gagal memproses settlement'); }
    finally { setLoading(false); }
  };

  const handleFinishSplit = async () => {
    if (!receipt || !user) return;
    setLoading(true);
    try {
      const finalTotal = getFinalTotal();
      const currentSubtotal = receipt.items.reduce((acc, item) => acc + (item.price * (item.qty || 1)), 0);
      
      const { data: rcpt, error: rcptError } = await supabase.from('receipts').insert({
        user_id: user.id,
        payer_id: selectedLenderId, // Fitur #2
        store_name: receipt.store_name || 'Struk Baru',
        subtotal: currentSubtotal,
        tax: receipt.tax || 0,
        service_charge: receipt.serviceCharge || 0,
        discount: receipt.discount || 0,
        total_amount: finalTotal,
        items_raw: JSON.stringify(receipt.items),
        participants_snapshot: JSON.stringify(participants)
      }).select().single();

      if (rcptError) throw rcptError;

      const feeRatio = currentSubtotal > 0 ? (finalTotal - currentSubtotal) / currentSubtotal : 0;
      const debtRecords = participants
        .filter(p => p.id !== selectedLenderId)
        .map(p => {
          const personSubtotal = p.items.reduce((sum, itemIdx) => {
            const item = receipt.items[itemIdx];
            const sharersCount = participants.filter(pp => pp.items.includes(itemIdx)).length;
            return sum + ((item.price * (item.qty || 1)) / (sharersCount || 1));
          }, 0);

          return {
            receipt_id: rcpt.id,
            lender_id: selectedLenderId,
            debtor_id: p.type === 'friend' ? p.id : null,
            debtor_name: p.type === 'dummy' ? p.name : null,
            amount: Math.round(personSubtotal + (personSubtotal * feeRatio)),
            is_paid: false,
            status: 'pending'
          };
        }).filter(d => d.amount > 0);

      if (debtRecords.length > 0) await supabase.from('debts').insert(debtRecords);

      alert('Berhasil disimpan! 🚀');
      setStep('dashboard');
      fetchDashboardData(user.id);
    } catch (err) { alert('Gagal menyimpan'); }
    finally { setLoading(false); }
  };

  // --- RENDER DASHBOARD ---
  const renderDashboard = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Banner Announcement Fitur #1 */}
      {offsetSuggestions.map((opt, i) => (
        <div key={i} className="bg-gradient-to-r from-amber-500 to-orange-500 p-6 rounded-[2.5rem] text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-white/20 p-4 rounded-2xl"><RefreshCw className="animate-spin-slow" size={28}/></div>
            <div>
              <p className="font-black text-xl tracking-tight">Potong Utang Otomatis!</p>
              <p className="text-sm opacity-90 font-medium">Kamu & {opt.friendName} bisa saling potong tagihan. Mau diselesaikan?</p>
            </div>
          </div>
          <button onClick={() => handleOffset(opt)} className="bg-white text-orange-600 px-8 py-3 rounded-2xl font-black shadow-lg hover:scale-105 transition-all">Selesaikan Sekarang</button>
        </div>
      ))}

      {/* Upload Section */}
      <div className="bg-white border-2 border-dashed border-amber-200 rounded-[3rem] p-12 text-center group shadow-sm transition-all hover:border-amber-400">
        <div className="bg-amber-500 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:rotate-6 transition-transform">
          <Camera className="text-white" size={36} />
        </div>
        <h2 className="text-3xl font-black text-[#2D2924] mb-3">Scan Bill Baru</h2>
        <p className="text-gray-500 text-sm mb-10">AI akan otomatis memisahkan harga makanan & pajak.</p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button onClick={() => fileInputRef.current?.click()} className="bg-amber-500 text-white px-10 py-4 rounded-2xl font-black shadow-lg">Ambil Foto</button>
          <input type="file" className="hidden" accept="image/*" ref={fileInputRef} onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              const reader = new FileReader();
              reader.readAsDataURL(file);
              reader.onload = async () => {
                setPreview(reader.result as string);
                setLoading(true);
                const res = await processReceipt(reader.result as string);
                setReceipt(res as any);
                setStep('edit');
                setLoading(false);
              };
            }
          }} />
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-amber-50 relative overflow-hidden">
          <p className="text-[10px] font-black text-green-600 uppercase tracking-widest mb-2">Piutang Kamu</p>
          <h3 className="text-4xl font-black text-[#2D2924]">Rp {stats.piutang.toLocaleString()}</h3>
          <ArrowUpRight className="absolute bottom-6 right-6 text-green-100" size={60} />
        </div>
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-amber-50 relative overflow-hidden">
          <p className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-2">Hutang Kamu</p>
          <h3 className="text-4xl font-black text-[#2D2924]">Rp {stats.hutang.toLocaleString()}</h3>
          <ArrowDownLeft className="absolute bottom-6 right-6 text-red-100" size={60} />
        </div>
      </div>

      {/* HISTORY SECTION (BALIK LAGI!) */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-xl font-black flex items-center gap-2"><Clock size={20} className="text-amber-600"/> History Transaksi</h3>
          <button className="text-sm font-bold text-amber-600">Lihat Semua</button>
        </div>
        <div className="grid grid-cols-1 gap-4">
          {history.length > 0 ? history.map((item) => (
            <div key={item.id} className="bg-white p-6 rounded-[2rem] border border-amber-50 shadow-sm flex items-center justify-between hover:border-amber-200 transition-all cursor-pointer group">
              <div className="flex items-center gap-4">
                <div className="bg-amber-50 p-3 rounded-2xl group-hover:bg-amber-500 group-hover:text-white transition-all">
                  <Receipt size={24} />
                </div>
                <div>
                  <p className="font-black text-[#2D2924]">{item.store_name || 'Restoran Tanpa Nama'}</p>
                  <p className="text-xs text-gray-400 font-medium">{new Date(item.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-black text-amber-600">Rp {item.total_amount.toLocaleString()}</p>
                <ChevronRight size={16} className="ml-auto text-gray-300" />
              </div>
            </div>
          )) : (
            <div className="bg-white/50 border-2 border-dashed border-gray-200 rounded-[2rem] p-12 text-center text-gray-400 font-bold">
              Belum ada transaksi tersimpan.
            </div>
          )}
        </div>
      </div>
    </div>
  );

  // --- RENDER EDIT ---
  const renderEdit = () => (
    <div className="max-w-5xl mx-auto animate-in fade-in duration-500">
      <div className="bg-white rounded-[3rem] p-10 shadow-2xl border border-amber-100">
        <div className="flex flex-col lg:flex-row gap-10">
          <div className="w-full lg:w-1/3">
            <p className="text-xs font-black text-amber-500 uppercase mb-4">Preview Struk</p>
            <div className="rounded-[2rem] overflow-hidden border-4 border-amber-50 shadow-inner">
              {preview && <img src={preview} alt="Struk" className="w-full grayscale hover:grayscale-0 transition-all duration-500" />}
            </div>
          </div>
          <div className="flex-1">
            <h2 className="text-3xl font-black mb-8 tracking-tighter italic">Review & Edit Bill ✍️</h2>
            <div className="space-y-3 mb-8">
              {receipt?.items.map((item, i) => (
                <div key={i} className="flex gap-3 items-center bg-gray-50/50 p-4 rounded-2xl border border-gray-100">
                  <input value={item.name} onChange={(e) => {
                    const ni = [...receipt.items]; ni[i].name = e.target.value; setReceipt({...receipt, items: ni});
                  }} className="flex-1 bg-white p-3 rounded-xl font-bold text-sm shadow-sm border-none" />
                  <input type="number" value={item.price} onChange={(e) => {
                    const ni = [...receipt.items]; ni[i].price = +e.target.value; setReceipt({...receipt, items: ni});
                  }} className="w-28 bg-white p-3 rounded-xl font-black text-sm text-amber-600 shadow-sm border-none" />
                  <button onClick={() => setReceipt({...receipt!, items: receipt!.items.filter((_, idx) => idx !== i)})} className="p-2 text-red-300 hover:text-red-500 transition-colors"><Trash2 size={18}/></button>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-4 mb-8 bg-amber-50/50 p-6 rounded-3xl">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-amber-600 uppercase ml-2 flex items-center gap-1"><Percent size={10}/> Tax</label>
                <input type="number" value={receipt?.tax || 0} onChange={(e) => setReceipt({...receipt!, tax: +e.target.value})} className="w-full p-3 bg-white rounded-xl font-bold text-sm border-none" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-amber-600 uppercase ml-2 flex items-center gap-1"><BadgePercent size={10}/> Svc</label>
                <input type="number" value={receipt?.serviceCharge || 0} onChange={(e) => setReceipt({...receipt!, serviceCharge: +e.target.value})} className="w-full p-3 bg-white rounded-xl font-bold text-sm border-none" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-green-600 uppercase ml-2 flex items-center gap-1"><ArrowDownLeft size={10}/> Disc</label>
                <input type="number" value={receipt?.discount || 0} onChange={(e) => setReceipt({...receipt!, discount: +e.target.value})} className="w-full p-3 bg-white rounded-xl font-bold text-sm border-none text-green-600" />
              </div>
            </div>
            <div className="flex items-center justify-between pt-6 border-t border-amber-100">
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase">Total Bill</p>
                <p className="text-3xl font-black">Rp {getFinalTotal().toLocaleString()}</p>
              </div>
              <button onClick={() => setStep('assign')} className="bg-amber-500 text-white px-12 py-4 rounded-2xl font-black shadow-lg">Lanjut Bagi →</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // --- RENDER ASSIGN (FITUR #2) ---
  const renderAssign = () => (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="bg-white rounded-[3rem] p-10 shadow-2xl border border-amber-100">
        <h2 className="text-3xl font-black mb-10 text-center tracking-tighter">Bagi-Bagi Bill 🍕</h2>
        
        {/* Fitur #2: Siapa yang bayar? */}
        <div className="mb-10 p-8 bg-amber-50 rounded-[2.5rem] border border-amber-200/50 shadow-inner">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles size={20} className="text-amber-500 animate-pulse"/>
            <p className="text-sm font-black text-amber-900 uppercase tracking-widest">Siapa yang bayarin struk ini?</p>
          </div>
          <div className="flex flex-wrap gap-3">
            {participants.map(p => (
              <button 
                key={p.id} 
                onClick={() => setSelectedLenderId(p.id)}
                className={`px-6 py-3 rounded-2xl font-black text-sm transition-all duration-300 ${selectedLenderId === p.id ? 'bg-amber-500 text-white shadow-xl scale-105 ring-4 ring-amber-100' : 'bg-white text-gray-400 border border-amber-100 hover:border-amber-300'}`}
              >
                {p.name} {p.id === user?.id ? '(Me)' : ''}
              </button>
            ))}
          </div>
        </div>

        {/* Input Teman */}
        <div className="mb-12">
          <div className="flex flex-wrap gap-2 mb-4">
            {participants.map((p, i) => (
              <div key={i} className="bg-white px-4 py-2 rounded-xl border border-amber-200 flex items-center gap-2 font-bold text-xs shadow-sm">
                {p.name}
                {p.id !== user?.id && <button onClick={() => setParticipants(participants.filter(pt => pt.id !== p.id))} className="text-red-300">×</button>}
              </div>
            ))}
          </div>
          <input 
            placeholder="Tambah nama teman..." 
            className="w-full p-5 rounded-[2rem] border-2 border-amber-100 focus:outline-none focus:border-amber-500 font-bold bg-gray-50/50 transition-all"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const val = (e.target as HTMLInputElement).value;
                if (val) setParticipants([...participants, { id: `dummy-${Date.now()}`, name: val, type: 'dummy', items: [] }]);
                (e.target as HTMLInputElement).value = '';
              }
            }}
          />
        </div>

        {/* Item Split */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          {receipt?.items.map((item, itemIdx) => (
            <div key={itemIdx} className="bg-white p-6 rounded-[2rem] border-2 border-gray-50 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <p className="font-black text-sm text-[#2D2924]">{item.name}</p>
                <p className="font-black text-amber-600 text-sm">Rp {item.price.toLocaleString()}</p>
              </div>
              <div className="flex flex-wrap gap-2 border-t border-dashed border-gray-100 pt-4">
                {participants.map((p, pIdx) => (
                  <button 
                    key={pIdx} 
                    onClick={() => {
                      const newP = [...participants];
                      if (newP[pIdx].items.includes(itemIdx)) {
                        newP[pIdx].items = newP[pIdx].items.filter(idx => idx !== itemIdx);
                      } else {
                        newP[pIdx].items.push(itemIdx);
                      }
                      setParticipants(newP);
                    }}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${p.items.includes(itemIdx) ? 'bg-amber-500 text-white shadow-md' : 'bg-gray-50 text-gray-300 hover:bg-amber-100'}`}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <button onClick={handleFinishSplit} disabled={loading} className="w-full bg-[#2D2924] text-white py-6 rounded-[2.5rem] font-black text-xl shadow-2xl hover:bg-black transition-all active:scale-95">
          {loading ? 'MENYIMPAN...' : 'SIMPAN TAGIHAN ✨'}
        </button>
      </div>
    </div>
  );

  if (loading && step === 'dashboard') return (
    <div className="min-h-screen bg-[#FDFCF0] flex flex-col items-center justify-center">
      <div className="w-16 h-16 border-4 border-amber-200 border-t-amber-500 rounded-full animate-spin mb-4" />
      <h1 className="font-black text-xl text-amber-800 animate-pulse tracking-tighter uppercase">Menyiapkan Dashboard...</h1>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#FDFCF0] text-[#4A4238] font-sans pb-40">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <header className="flex flex-col items-center mb-12 animate-in fade-in duration-1000">
          <div className="bg-amber-500 text-white px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">Urunin v3.0</div>
          <h1 className="text-5xl font-black text-[#2D2924] tracking-tighter italic">Halo, {user?.user_metadata?.full_name?.split(' ')[0] || 'Kawan'}! 👋</h1>
        </header>

        {step === 'dashboard' && renderDashboard()}
        {step === 'edit' && renderEdit()}
        {step === 'assign' && renderAssign()}
      </div>
    </div>
  );
}