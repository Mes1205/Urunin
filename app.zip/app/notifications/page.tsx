//app/notifications/page.tsx

"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Bell, Receipt, UserCheck, CheckCheck } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NotificationsPage() {
  const router = useRouter();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotifs = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }

      const { data } = await supabase
        .from('notifications')
        .select(`
          id, message, created_at, is_read, receipt_id,
          sender:sender_id (id, name, email)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (data) setNotifications(data);
      setLoading(false);
    };

    fetchNotifs();
  }, []);

  const markAllRead = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  const getIcon = (msg: string) => {
    const message = msg.toLowerCase();
    // Ikon untuk Martha (Konfirmasi Pembayaran)
    if (message.includes('konfirmasi') || message.includes('meminta')) {
      return <CheckCheck size={20} className="text-blue-600"/>;
    }
    // Ikon untuk Tagihan Baru
    if (message.includes('tagihan') || message.includes('split')) {
      return <Receipt size={20} className="text-amber-600"/>;
    }
    // Ikon untuk Pertemanan
    if (message.includes('teman') || message.includes('menerima')) {
      return <UserCheck size={20} className="text-green-600"/>;
    }
    return <Bell size={20} className="text-gray-500"/>;
  };

  // LOGIC CLICK DISINI
  const handleNotificationClick = async (notif: any) => {
    // 1. Tandai read dulu (opsional, biar UX bagus)
    if (!notif.is_read) {
       await supabase.from('notifications').update({ is_read: true }).eq('id', notif.id);
       setNotifications(prev => prev.map(n => n.id === notif.id ? { ...n, is_read: true } : n));
    }

    // 2. Arahkan sesuai tipe notif
    if (notif.receipt_id) {
      // Kalau ada receipt_id, berarti soal tagihan -> Buka detail struk
      router.push(`/receipt/${notif.receipt_id}`);
    } else if (notif.sender?.id) {
      // Kalau soal teman -> Buka profile pengirim
      router.push(`/profile/${notif.sender.id}`);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-24 px-6 pb-20">
      <div className="max-w-2xl mx-auto">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h1 className="text-3xl font-black text-[#2D2924]">Notifikasi</h1>
            <p className="text-[#877E71]">Update terbaru buat kamu.</p>
          </div>
          {notifications.some(n => !n.is_read) && (
            <button onClick={markAllRead} className="text-xs font-bold text-amber-600 flex items-center gap-1 hover:underline">
              <CheckCheck size={14}/> Tandai sudah dibaca
            </button>
          )}
        </div>

        {loading ? (
          <p className="text-center text-gray-400 mt-10">Memuat notifikasi...</p>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-[2rem] border border-dashed border-amber-200">
             <Bell size={40} className="mx-auto text-amber-200 mb-4"/>
             <p className="text-gray-400">Belum ada notifikasi masuk.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map((notif) => (
              <div 
                key={notif.id} 
                onClick={() => handleNotificationClick(notif)} // TAMBAH CLICK HANDLER
                className={`cursor-pointer p-5 rounded-2xl flex gap-4 items-start transition-all hover:scale-[1.01] active:scale-95 ${
                  notif.is_read ? 'bg-white border border-transparent' : 'bg-amber-50 border border-amber-100 shadow-sm'
                }`}
              >
                <div className={`mt-1 w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${notif.is_read ? 'bg-gray-50' : 'bg-white'}`}>
                  {getIcon(notif.message)}
                </div>
                <div className="flex-1">
                  <p className={`text-sm ${notif.is_read ? 'text-gray-600' : 'text-[#2D2924] font-bold'}`}>
                    {notif.message}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {new Date(notif.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    {notif.sender && <span className="mx-1">• dari {notif.sender.name || notif.sender.email}</span>}
                  </p>
                </div>
                {!notif.is_read && <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}