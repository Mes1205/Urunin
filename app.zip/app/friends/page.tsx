//app/friends/page.tsx
"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { UserMinus, Check, X, User } from 'lucide-react';

export default function FriendsPage() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [friends, setFriends] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Load Data
  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setCurrentUser(user);
      if (user) await loadData(user.id);
      setLoading(false);
    };
    init();
  }, []);

  const loadData = async (userId: string) => {
  try {
    // 1. Ambil Incoming Requests
    const { data: reqData } = await supabase
      .from('friend_requests')
      .select(`
        id,
        sender:profiles!sender_id (id, name, email, image_url)
      `)
      .eq('receiver_id', userId)
      .eq('status', 'pending');

    if (reqData) setRequests(reqData);

    // 2. Ambil Friends (PAKAI QUERY INI)
    // Pastikan ada tanda !friend_id untuk mempertegas relasi ke kolom tersebut
    const { data: friendData, error: friendError } = await supabase
      .from('friends')
      .select(`
        profiles!friend_id (
          id, 
          name, 
          email, 
          image_url
        )
      `)
      .eq('user_id', userId);

    if (friendError) {
      console.error("Detail Error Supabase:", friendError);
      return;
    }

    if (friendData) {
      // Karena query di atas returnnya { profiles: {id, name...} }
      // Kita map agar masuk ke state sebagai array user langsung
      const formattedFriends = friendData
        .map((f: any) => f.profiles)
        .filter((f) => f !== null); 
      
      setFriends(formattedFriends);
    }
  } catch (err) {
    console.error("System Error:", err);
  }
};
  
  // --- ACTIONS ---

  const handleRequest = async (requestId: string, senderId: string, action: 'accept' | 'reject') => {
    if (action === 'reject') {
       // Hapus request saja
       await supabase.from('friend_requests').delete().eq('id', requestId);
       setRequests(prev => prev.filter(r => r.id !== requestId));
       return;
    }

    if (action === 'accept') {
      try {
        // 1. Insert ke tabel friends (2 Arah)
        const updates = [
          { user_id: currentUser.id, friend_id: senderId },
          { user_id: senderId, friend_id: currentUser.id }
        ];
        await supabase.from('friends').insert(updates);

        // 2. Hapus dari request (atau update status jadi accepted, disini kita hapus aja biar bersih)
        await supabase.from('friend_requests').delete().eq('id', requestId);

        // 3. Kirim Notifikasi ke Sender bahwa diterima
        await supabase.from('notifications').insert({
          user_id: senderId,
          sender_id: currentUser.id,
          message: 'Menerima permintaan pertemananmu.',
        });

        // 4. Refresh UI
        loadData(currentUser.id);
        alert("Sekarang kalian mutualan! 🎉");

      } catch (err) {
        console.error(err);
        alert("Gagal menerima teman.");
      }
    }
  };

  const removeFriend = async (friendId: string) => {
    if (!confirm("Yakin mau hapus teman ini?")) return;
    
    // Hapus 2 arah
    await supabase.from('friends').delete()
      .or(`and(user_id.eq.${currentUser.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${currentUser.id})`);
    
    loadData(currentUser.id);
  };


  if (loading) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-24 px-6 pb-20">
      <div className="max-w-2xl mx-auto space-y-10">
        
        {/* --- SECTION 1: PERMINTAAN BERTEMAN (INCOMING) --- */}
        {requests.length > 0 && (
          <div className="animate-in fade-in slide-in-from-top-4">
             <h2 className="font-bold text-[#2D2924] mb-4 flex items-center gap-2">
               📩 Permintaan Masuk <span className="bg-red-500 text-white text-[10px] px-2 rounded-full">{requests.length}</span>
             </h2>
             <div className="bg-white rounded-[2rem] shadow-sm border border-amber-200 overflow-hidden">
               {requests.map((req) => (
                 <div key={req.id} className="p-5 border-b border-gray-50 last:border-0 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                       <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                         <User size={18} className="text-amber-700"/>
                       </div>
                       <div>
                         <p className="font-bold text-sm">{req.sender.name || req.sender.email}</p>
                         <p className="text-xs text-gray-400">Ingin mutualan</p>
                       </div>
                    </div>
                    <div className="flex gap-2">
                       <button onClick={() => handleRequest(req.id, req.sender.id, 'reject')} className="p-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-gray-500">
                         <X size={18}/>
                       </button>
                       <button onClick={() => handleRequest(req.id, req.sender.id, 'accept')} className="px-4 py-2 bg-[#2D2924] hover:bg-black rounded-xl text-white text-xs font-bold flex items-center gap-2">
                         <Check size={14}/> Terima
                       </button>
                    </div>
                 </div>
               ))}
             </div>
          </div>
        )}

        {/* --- SECTION 2: DAFTAR TEMAN --- */}
        <div>
           <h2 className="font-bold text-[#2D2924] mb-4">Mutual Friends ({friends.length})</h2>
           
           {friends.length === 0 ? (
             <div className="text-center py-12 bg-white rounded-[2rem] border border-dashed border-amber-200">
                <p className="text-gray-400 mb-2">Belum ada teman.</p>
                <p className="text-sm text-amber-600">Cari teman lewat search bar di atas!</p>
             </div>
           ) : (
             <div className="grid gap-3">
               {friends.map((friend) => (
                 <div key={friend.id} className="bg-white p-4 rounded-2xl border border-amber-50 flex justify-between items-center shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-400 font-bold">
                        {friend.name ? friend.name[0].toUpperCase() : 'U'}
                      </div>
                      <div>
                        <p className="font-bold text-[#2D2924]">{friend.name || 'User'}</p>
                        <p className="text-xs text-gray-400">{friend.email}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeFriend(friend.id)}
                      className="text-red-300 hover:text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors"
                      title="Unfriend"
                    >
                      <UserMinus size={18} />
                    </button>
                 </div>
               ))}
             </div>
           )}
        </div>

      </div>
    </div>
  );
}