"use client"; 

import { usePathname } from "next/navigation";
import Navbar from "../components/navbar";
import "./globals.css";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  // Daftar halaman yang TIDAK boleh ada Navbar-nya
  const disableNavbar = ["/login"];

  return (
    <html lang="en">
      <body>
        {/* Hanya tampilkan Navbar jika pathname saat ini tidak ada di daftar disableNavbar */}
        {!disableNavbar.includes(pathname) && <Navbar />}
        
        <main>
          {children}
        </main>
      </body>
    </html>
  );
}