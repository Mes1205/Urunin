"use server";

import { GoogleGenerativeAI } from "@google/generative-ai";
import { supabaseServer } from "@/lib/supabase/server";

/* =========================
   Setup Gemini
========================= */

const apiKey = process.env.GEMINI_API_KEY?.trim();

if (!apiKey) {
  throw new Error("GEMINI_API_KEY belum diset di environment.");
}

const genAI = new GoogleGenerativeAI(apiKey);

/* =========================
   Helper
========================= */

const safeNumber = (val: any): number => {
  const num = Number(val);
  return isNaN(num) ? 0 : num;
};

const cleanJson = (text: string) =>
  text.replace(/```json|```/g, "").trim();

/* =========================
   Server Action
========================= */

export async function processReceipt(base64Image: string) {
  try {
    /* ===== Gemini Model ===== */
    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash",
      generationConfig: {
        responseMimeType: "application/json",
      },
    });

    const prompt = `
Analisis struk ini secara detail.

Output HARUS berupa JSON VALID tanpa penjelasan tambahan.

Format:
{
  "storeName": "Nama Toko",
  "items": [
    { "name": "Item", "price": 0, "qty": 1 }
  ],
  "subtotal": 0,
  "tax": 0,
  "serviceCharge": 0,
  "discount": 0,
  "totalAmount": 0
}
`;

    const imageData = base64Image.split(",")[1];

    const mimeType = base64Image.includes("png")
      ? "image/png"
      : "image/jpeg";

    const result = await model.generateContent([
      prompt,
      {
        inlineData: {
          data: imageData,
          mimeType,
        },
      },
    ]);

    /* ===== Parse JSON Aman ===== */
    const rawText = result.response.text();
    const parsed = JSON.parse(cleanJson(rawText));

    /* ===== Simpan ke Supabase ===== */
    const { data: saved, error } = await supabaseServer
      .from("receipts")
      .insert({
        store_name: parsed.storeName || "Unknown Store",
        subtotal: safeNumber(parsed.subtotal),
        tax: safeNumber(parsed.tax),
        service_charge: safeNumber(parsed.serviceCharge),
        discount: safeNumber(parsed.discount),
        total_amount: safeNumber(parsed.totalAmount),
        items_raw: JSON.stringify(parsed.items || []),
      })
      .select()
      .single();

    if (error) throw error;

    /* ===== Return ke Client (camelCase) ===== */
    return {
      id: saved.id,
      storeName: saved.store_name,
      items: JSON.parse(saved.items_raw),
      subtotal: saved.subtotal,
      tax: saved.tax,
      serviceCharge: saved.service_charge,
      discount: saved.discount,
      totalAmount: saved.total_amount,
      createdAt: saved.created_at,
    };
  } catch (err: any) {
    console.error("processReceipt error:", err);
    throw new Error(err.message || "Gagal memproses struk.");
  }
}
