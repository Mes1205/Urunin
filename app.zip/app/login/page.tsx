
//app/login/page.tsx
"use client";

import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Zap, Mail, Lock, User as UserIcon } from 'lucide-react';

export default function AuthPage() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        // Proses Sign Up
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName }, // Masuk ke metadata user
          },
        });
        if (error) throw error;
        alert('Cek email kamu untuk verifikasi!');
      } else {
        // Proses Login
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push('/'); // Pindah ke home/ocr setelah login berhasil
        router.refresh();
      }
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCF0] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-xl border border-amber-100 p-8 md:p-10">
        
        {/* Logo & Header */}
        <div className="text-center mb-8">
          <div className="inline-flex bg-amber-600 p-3 rounded-2xl mb-4 shadow-lg shadow-amber-900/20">
            <Zap size={32} className="text-white fill-current" />
          </div>
          <h1 className="text-3xl font-black text-[#2D2924]">
            {isSignUp ? 'Gabung Urunin.' : 'Selamat Datang!'}
          </h1>
          <p className="text-[#877E71] mt-2">
            {isSignUp ? 'Mulai bagi bill dengan adil dan cepat.' : 'Masuk untuk mengelola hutang piutangmu.'}
          </p>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {isSignUp && (
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8A296]" size={18} />
              <input
                type="text"
                placeholder="Nama Lengkap"
                className="w-full bg-[#F9F8F3] border-none rounded-2xl py-4 pl-12 pr-4 text-sm text-black focus:ring-2 focus:ring-amber-400 outline-none placeholder-[#A8A296]"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
          )}

          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8A296]" size={18} />
            <input
              type="email"
              placeholder="Email"
              className="w-full bg-[#F9F8F3] border-none rounded-2xl py-4 pl-12 pr-4 text-sm text-black focus:ring-2 focus:ring-amber-400 outline-none placeholder-[#A8A296]"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A8A296]" size={18} />
            <input
              type="password"
              placeholder="Password"
              className="w-full bg-[#F9F8F3] border-none rounded-2xl py-4 pl-12 pr-4 text-sm text-black focus:ring-2 focus:ring-amber-400 outline-none placeholder-[#A8A296]"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#2D2924] text-white py-4 rounded-2xl font-bold hover:bg-black transition-all shadow-lg shadow-gray-200 mt-2 disabled:opacity-50"
          >
            {loading ? 'Memproses...' : isSignUp ? 'Daftar Sekarang' : 'Masuk'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-sm text-[#877E71]">
            {isSignUp ? 'Sudah punya akun?' : 'Belum punya akun?'} {' '}
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-amber-600 font-bold hover:underline"
            >
              {isSignUp ? 'Masuk di sini' : 'Daftar gratis'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}