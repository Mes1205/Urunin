//app/piutang/page.tsx

"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Receipt, User, Send, CheckCircle2, Clock, AlertCircle } from 'lucide-react';

export default function PiutangPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [piutangList, setPiutangList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }
      setCurrentUser(user);

      // Ambil semua piutang (dimana saya adalah lender)
      const { data: debts } = await supabase
        .from('debts')
        .select(`
          id, amount, status, is_paid, created_at,
          receipt:receipts(id, store_name, total_amount, created_at),
          debtor:profiles!debtor_id(id, name, email)
        `)
        .eq('lender_id', user.id)
        .eq('is_paid', false)
        .order('created_at', { ascending: false });

      setPiutangList(debts || []);
      setLoading(false);
    };

    fetchData();
  }, []);

  const sendReminder = async (debtId: string, debtorId: string, receiptName: string) => {
    setSending(debtId);
    
    try {
      await supabase.from('notifications').insert({
        user_id: debtorId,
        sender_id: currentUser.id,
        message: `🔔 Reminder: Tagihan "${receiptName}" belum dibayar.`,
      });

      alert('Reminder berhasil dikirim! 📨');
    } catch (err) {
      alert('Gagal mengirim reminder');
    } finally {
      setSending(null);
    }
  };

  const groupByDebtor = () => {
  const grouped = new Map<string, { debtor: any; debts: any[]; total: number }>();
  
  piutangList.forEach((debt: any) => {
    // 1. Cek apakah debtor ada, jika tidak pakai fallback untuk 'Dummy/Anonim'
    const debtorId = debt.debtor?.id || `dummy-${debt.debtor_name}`;
    const debtorInfo = debt.debtor || { 
      id: debtorId, 
      name: debt.debtor_name || 'Teman Manual', 
      email: 'Tanpa Akun' 
    };

    if (!grouped.has(debtorId)) {
      grouped.set(debtorId, {
        debtor: debtorInfo,
        debts: [],
        total: 0
      });
    }
    
    const group = grouped.get(debtorId)!;
    group.debts.push(debt);
    group.total += debt.amount;
  });
  
  return Array.from(grouped.values());
};

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <span className="flex items-center gap-1 text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded-full font-black"><CheckCircle2 size={10}/> Lunas</span>;
      case 'waiting_confirmation':
        return <span className="flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 px-2 py-1 rounded-full font-black"><Clock size={10}/> Menunggu</span>;
      default:
        return <span className="flex items-center gap-1 text-[10px] bg-red-100 text-red-700 px-2 py-1 rounded-full font-black"><AlertCircle size={10}/> Belum Bayar</span>;
    }
  };

  if (loading) return <div className="p-10 text-center font-black animate-pulse">MEMUAT PIUTANG...</div>;

  const groupedData = groupByDebtor();
  const totalPiutang = piutangList.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-6 px-6 pb-20">
      <div className="max-w-3xl mx-auto">
        
        {/* Header */}
        <button onClick={() => router.push('/')} className="mb-6 flex items-center gap-2 text-gray-500 hover:text-[#2D2924] font-bold">
          <ArrowLeft size={18}/> Kembali
        </button>

        <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-[2.5rem] p-10 mb-8 shadow-xl">
          <div className="flex items-center gap-2 mb-2 text-green-100 text-xs font-black uppercase tracking-widest">
            <Receipt size={14}/> Total Piutang
          </div>
          <h1 className="text-5xl font-black mb-2">Rp {totalPiutang.toLocaleString()}</h1>
          <p className="text-green-100 text-sm">Dari {piutangList.length} tagihan • {groupedData.length} orang</p>
        </div>

        {/* List by Person */}
        <div className="space-y-6">
          {groupedData.length === 0 ? (
            <div className="bg-white p-10 rounded-[2.5rem] border border-dashed border-gray-200 text-center">
              <p className="text-gray-400 font-bold">Belum ada piutang aktif 🎉</p>
            </div>
          ) : (
            groupedData.map((group, idx) => (
              <div key={idx} className="bg-white rounded-[2.5rem] border border-amber-100 shadow-lg overflow-hidden">
                
                {/* Header Person */}
                <div 
                  onClick={() => router.push(`/profile/${group.debtor.id}`)}
                  className="bg-amber-50 p-6 flex items-center justify-between cursor-pointer hover:bg-amber-100 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center shadow-lg">
                      <User className="text-white" size={24}/>
                    </div>
                    <div>
                      <h3 className="font-black text-[#2D2924] text-lg">{group.debtor.name || 'Tanpa Nama'}</h3>
                      <p className="text-xs text-gray-500">{group.debtor.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">Total Hutang</p>
                    <p className="text-2xl font-black text-green-600">Rp {group.total.toLocaleString()}</p>
                  </div>
                </div>

                {/* Detail Bills */}
                <div className="p-6 space-y-4">
                  {group.debts.map((debt) => (
                    <div key={debt.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                      <div 
                        onClick={() => router.push(`/receipt/${debt.receipt.id}`)}
                        className="flex-1 cursor-pointer"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-sm text-[#2D2924]">{debt.receipt.store_name}</h4>
                          {getStatusBadge(debt.status)}
                        </div>
                        <p className="text-xs text-gray-400">{new Date(debt.created_at).toLocaleDateString('id-ID')}</p>
                        <p className="text-sm font-black text-green-600 mt-1">Rp {debt.amount.toLocaleString()}</p>
                      </div>
                      
                      {debt.status === 'pending' && (
                        <button 
                          onClick={() => sendReminder(debt.id, debt.debtor.id, debt.receipt.store_name)}
                          disabled={sending === debt.id}
                          className="ml-4 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-black disabled:opacity-50"
                        >
                          {sending === debt.id ? 'Mengirim...' : <><Send size={14}/> Ingatkan</>}
                        </button>
                      )}
                    </div>
                  ))}
                </div>

              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
}