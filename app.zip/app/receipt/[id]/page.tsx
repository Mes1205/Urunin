//app/receipt/[id]/page.tsx

"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Calendar, Receipt as ReceiptIcon, Users, CheckCircle2, Clock, Send, Ghost } from 'lucide-react';

export default function ReceiptDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [receipt, setReceipt] = useState<any>(null);
  const [participants, setParticipants] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [debts, setDebts] = useState<any[]>([]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setCurrentUser(user);

      const { data: rcpt, error } = await supabase
        .from('receipts')
        .select('*')
        .eq('id', id)
        .single();

      if (error || !rcpt) {
        alert("Struk tidak ditemukan");
        router.back();
        return;
      }

      const { data: debtData } = await supabase
        .from('debts')
        .select('*')
        .eq('receipt_id', id);

      setReceipt(rcpt);
      setDebts(debtData || []);
      setItems(JSON.parse(rcpt.items_raw || '[]'));
      if (rcpt.participants_snapshot) {
        setParticipants(JSON.parse(rcpt.participants_snapshot));
      }
      setLoading(false);
    };

    fetchData();
  }, [id]);

  const getAdditionalFees = (price: number) => {
    if (!receipt || receipt.subtotal === 0) return 0;
    const totalFees = receipt.total_amount - receipt.subtotal;
    const ratio = price / receipt.subtotal;
    return Math.round(totalFees * ratio);
  };

  const getPersonDetails = (personIdx: number) => {
    const person = participants[personIdx];
    if (!person || !person.items) return [];

    return person.items.map((itemIdx: number) => {
      const item = items[itemIdx];
      if (!item) return null;

      const sharers = participants.filter((p: any) => p.items?.includes(itemIdx));
      const basePrice = (item.price || 0) * (item.qty || 0);
      const additional = getAdditionalFees(basePrice);
      
      return {
        name: item.name || "Item",
        priceEach: Math.round((basePrice + additional) / (sharers.length || 1)),
        sharersCount: sharers.length || 1
      };
    }).filter(Boolean);
  };

  const handleConfirmPayment = async (debtId: string) => {
    const note = prompt("Catatan transfer:", "Sudah ya!");
    if (note === null) return;
    setIsSubmitting(true);
    const { error } = await supabase
      .from('debts')
      .update({ status: 'waiting_confirmation', debtor_note: note })
      .eq('id', debtId);
    
    if (!error) {
      await supabase.from('notifications').insert({
        user_id: receipt.user_id,
        sender_id: currentUser.id,
        receipt_id: receipt.id,
        message: `${currentUser.email} konfirmasi bayar: ${receipt.store_name}`,
      });
      window.location.reload();
    }
    setIsSubmitting(false);
  };

  const handleApprovePayment = async (debtId: string) => {
    if (!confirm("Konfirmasi pembayaran ini lunas?")) return;
    setIsSubmitting(true);
    const { error } = await supabase
      .from('debts')
      .update({ status: 'paid', is_paid: true })
      .eq('id', debtId);
    
    if (!error) window.location.reload();
    setIsSubmitting(false);
  };

  if (loading) return <div className="p-10 text-center font-black text-amber-800 animate-pulse">MEMUAT RINCIAN...</div>;

  const isLender = currentUser?.id === receipt.user_id;

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-6 px-6 pb-20 text-[#2D2924]">
      <div className="max-w-2xl mx-auto">
        <button onClick={() => router.push('/')} className="mb-6 flex items-center gap-2 text-gray-400 hover:text-black font-black uppercase text-xs tracking-widest transition-all">
          <ArrowLeft size={16}/> Kembali ke Beranda
        </button>

        <div className="bg-white rounded-[3rem] shadow-2xl border border-amber-100 overflow-hidden">
          {/* Header */}
          <div className="bg-[#2D2924] p-10 text-white relative">
            <div className="absolute top-0 right-0 bg-amber-500 text-black px-8 py-3 rounded-bl-[2rem] font-black text-[10px] uppercase tracking-widest">
              {isLender ? "PENAGIH" : "PEMBAYAR"}
            </div>
            <h1 className="text-4xl font-black mb-2 italic uppercase tracking-tighter">{receipt.store_name}</h1>
            <div className="flex items-center gap-4 text-gray-400 text-[10px] font-bold uppercase tracking-widest">
              <span className="flex items-center gap-1"><Calendar size={12}/> {new Date(receipt.created_at).toLocaleDateString('id-ID')}</span>
              <span className="flex items-center gap-1 text-amber-500"><Users size={12}/> {participants.length} Orang</span>
            </div>
          </div>

          <div className="p-8 space-y-8">
            {participants.map((p, i) => {
              const details = getPersonDetails(i);
              const personDebt = debts.find(d => d.debtor_id === p.id);
              const totalAmount = details.reduce((acc: number, curr: any) => acc + curr.priceEach, 0);
              const isDummy = p.type === 'dummy';
              const status = personDebt?.status || (isDummy ? 'pending' : 'pending');

              return (
                <div key={i} className={`rounded-[2.5rem] border-2 p-7 transition-all ${
                  status === 'paid' ? 'bg-green-50 border-green-200' : 
                  status === 'waiting_confirmation' ? 'bg-amber-50 border-amber-200' : 'bg-gray-50 border-gray-100'
                }`}>
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner ${isDummy ? 'bg-gray-200' : 'bg-amber-400'}`}>
                        {isDummy ? <Ghost className="text-gray-500" /> : <Users className="text-amber-900" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                            <h4 className="font-black text-xl text-[#2D2924]">{p.name}</h4>
                            {isDummy && <span className="bg-gray-200 text-[8px] px-2 py-0.5 rounded-full font-black text-gray-500">DUMMY</span>}
                        </div>
                        <p className={`text-[10px] font-black uppercase mt-1 ${
                          status === 'paid' ? 'text-green-600' : 
                          status === 'waiting_confirmation' ? 'text-amber-600' : 'text-red-500'
                        }`}>
                          {status === 'paid' ? '• Lunas' : status === 'waiting_confirmation' ? '• Menunggu Konfirmasi' : '• Belum Bayar'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-black italic">Rp {totalAmount.toLocaleString()}</p>
                    </div>
                  </div>

                  {/* Rincian Item */}
                  <div className="bg-white/50 rounded-2xl p-4 space-y-2 mb-6">
                    {details.map((item: any, idx: number) => (
                      <div key={idx} className="flex justify-between text-xs font-medium text-gray-500">
                        <span>{item.name} <span className="text-[10px] opacity-60">({item.sharersCount > 1 ? `Bagi ${item.sharersCount}` : 'Sendiri'})</span></span>
                        <span className="font-bold text-gray-700">Rp {item.priceEach.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {/* User biasa bayar */}
                    {!isLender && currentUser?.id === p.id && status === 'pending' && (
                      <button onClick={() => handleConfirmPayment(personDebt.id)} className="w-full bg-[#2D2924] text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2">
                        <Send size={14}/> Kirim Bukti Bayar
                      </button>
                    )}

                    {/* Owner konfirmasi user atau dummy */}
                    {isLender && (status === 'waiting_confirmation' || (isDummy && status === 'pending')) && (
                      <button onClick={() => handleApprovePayment(personDebt?.id)} className="w-full bg-green-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-green-700 transition-all flex items-center justify-center gap-2">
                        <CheckCircle2 size={14}/> {isDummy ? "Tandai Lunas (Manual)" : "Konfirmasi Pembayaran"}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grand Total Footer */}
          <div className="bg-amber-50 p-10 border-t-4 border-dashed border-white">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-[10px] font-black text-amber-800 uppercase tracking-[0.2em]">Total Keseluruhan</p>
                <h2 className="text-4xl font-black italic text-[#2D2924]">Rp {receipt.total_amount.toLocaleString()}</h2>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-amber-200 rotate-3 shadow-sm">
                <ReceiptIcon size={32} className="text-amber-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}