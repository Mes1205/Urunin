//app/hutang/page.tsx

"use client";

import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Receipt, User, CreditCard, CheckCircle2, Clock, AlertCircle, Send } from 'lucide-react';

export default function HutangPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [hutangList, setHutangList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }
      setCurrentUser(user);

      // Ambil semua hutang (dimana saya adalah debtor)
      const { data: debts } = await supabase
        .from('debts')
        .select(`
          id, amount, status, is_paid, created_at, debtor_note,
          receipt:receipts(id, store_name, total_amount, created_at),
          lender:profiles!lender_id(id, name, email)
        `)
        .eq('debtor_id', user.id)
        .eq('is_paid', false)
        .order('created_at', { ascending: false });

      setHutangList(debts || []);
      setLoading(false);
    };

    fetchData();
  }, []);

  const handleConfirmPayment = async (debtId: string, lenderId: string, receiptName: string) => {
    const note = prompt("Masukkan catatan transfer (opsional):", "Sudah transfer ya!");
    if (note === null) return; // User cancelled
    
    setPaying(debtId);
    
    try {
      // Update status debt
      await supabase
        .from('debts')
        .update({ status: 'waiting_confirmation', debtor_note: note })
        .eq('id', debtId);

      // Send notification to lender
      await supabase.from('notifications').insert({
        user_id: lenderId,
        sender_id: currentUser.id,
        message: `💰 ${currentUser.user_metadata?.full_name || currentUser.email} konfirmasi pembayaran: ${receiptName}`,
      });

      alert('Konfirmasi pembayaran terkirim! ✅');
      window.location.reload();
    } catch (err) {
      alert('Gagal konfirmasi pembayaran');
    } finally {
      setPaying(null);
    }
  };

  const groupByLender = () => {
    const grouped = new Map<string, { lender: any; debts: any[]; total: number }>();
    hutangList.forEach((debt: any) => {
      const lenderId = debt.lender.id;
      if (!grouped.has(lenderId)) {
        grouped.set(lenderId, {
          lender: debt.lender,
          debts: [],
          total: 0
        });
      }
      const group = grouped.get(lenderId)!;
      group.debts.push(debt);
      group.total += debt.amount;
    });
    return Array.from(grouped.values());
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <span className="flex items-center gap-1 text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded-full font-black"><CheckCircle2 size={10}/> Lunas</span>;
      case 'waiting_confirmation':
        return <span className="flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 px-2 py-1 rounded-full font-black"><Clock size={10}/> Menunggu Konfirmasi</span>;
      default:
        return <span className="flex items-center gap-1 text-[10px] bg-red-100 text-red-700 px-2 py-1 rounded-full font-black"><AlertCircle size={10}/> Belum Bayar</span>;
    }
  };

  if (loading) return <div className="p-10 text-center font-black animate-pulse">MEMUAT HUTANG...</div>;

  const groupedData = groupByLender();
  const totalHutang = hutangList.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="min-h-screen bg-[#FDFCF0] pt-6 px-6 pb-20">
      <div className="max-w-3xl mx-auto">
        
        {/* Header */}
        <button onClick={() => router.push('/')} className="mb-6 flex items-center gap-2 text-gray-500 hover:text-[#2D2924] font-bold">
          <ArrowLeft size={18}/> Kembali
        </button>

        <div className="bg-gradient-to-br from-red-500 to-rose-600 text-white rounded-[2.5rem] p-10 mb-8 shadow-xl">
          <div className="flex items-center gap-2 mb-2 text-red-100 text-xs font-black uppercase tracking-widest">
            <CreditCard size={14}/> Total Hutang
          </div>
          <h1 className="text-5xl font-black mb-2">Rp {totalHutang.toLocaleString()}</h1>
          <p className="text-red-100 text-sm">Dari {hutangList.length} tagihan • {groupedData.length} orang</p>
        </div>

        {/* List by Person */}
        <div className="space-y-6">
          {groupedData.length === 0 ? (
            <div className="bg-white p-10 rounded-[2.5rem] border border-dashed border-gray-200 text-center">
              <p className="text-gray-400 font-bold">Tidak ada hutang! Kamu aman 🎉</p>
            </div>
          ) : (
            groupedData.map((group, idx) => (
              <div key={idx} className="bg-white rounded-[2.5rem] border border-amber-100 shadow-lg overflow-hidden">
                
                {/* Header Person */}
                <div 
                  onClick={() => router.push(`/profile/${group.lender.id}`)}
                  className="bg-red-50 p-6 flex items-center justify-between cursor-pointer hover:bg-red-100 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                      <User className="text-white" size={24}/>
                    </div>
                    <div>
                      <h3 className="font-black text-[#2D2924] text-lg">{group.lender.name || 'Tanpa Nama'}</h3>
                      <p className="text-xs text-gray-500">{group.lender.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">Total Hutang</p>
                    <p className="text-2xl font-black text-red-600">Rp {group.total.toLocaleString()}</p>
                  </div>
                </div>

                {/* Detail Bills */}
                <div className="p-6 space-y-4">
                  {group.debts.map((debt) => (
                    <div key={debt.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                      <div 
                        onClick={() => router.push(`/receipt/${debt.receipt.id}`)}
                        className="flex-1 cursor-pointer"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-sm text-[#2D2924]">{debt.receipt.store_name}</h4>
                          {getStatusBadge(debt.status)}
                        </div>
                        <p className="text-xs text-gray-400">{new Date(debt.created_at).toLocaleDateString('id-ID')}</p>
                        <p className="text-sm font-black text-red-600 mt-1">Rp {debt.amount.toLocaleString()}</p>
                        {debt.debtor_note && (
                          <p className="text-xs text-gray-500 italic mt-1">Catatan: {debt.debtor_note}</p>
                        )}
                      </div>
                      
                      {debt.status === 'pending' && (
                        <button 
                          onClick={() => handleConfirmPayment(debt.id, debt.lender.id, debt.receipt.store_name)}
                          disabled={paying === debt.id}
                          className="ml-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-black disabled:opacity-50"
                        >
                          {paying === debt.id ? 'Mengirim...' : <><Send size={14}/> Konfirmasi Bayar</>}
                        </button>
                      )}

                      {debt.status === 'waiting_confirmation' && (
                        <div className="ml-4 bg-amber-100 text-amber-700 px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2">
                          <Clock size={14}/> Menunggu
                        </div>
                      )}
                    </div>
                  ))}
                </div>

              </div>
            ))
          )}
        </div>

        {/* Tips Section */}
        {hutangList.length > 0 && (
          <div className="mt-8 bg-amber-50 border-2 border-dashed border-amber-200 rounded-[2rem] p-6">
            <h3 className="font-black text-amber-900 mb-2 flex items-center gap-2">
              💡 Tips Pembayaran
            </h3>
            <ul className="text-sm text-amber-800 space-y-1">
              <li>• Klik "Konfirmasi Bayar" setelah transfer</li>
              <li>• Pemilik bill akan approve pembayaranmu</li>
              <li>• Pastikan nominal transfer sudah sesuai</li>
            </ul>
          </div>
        )}

      </div>
    </div>
  );
}